

var bird = {
	div:document.createElement("div"),
	waingTimer:null,
	flyBirdTimer:null,//下落的定时器

	showBird:function(parentObj) {
	this.div.style.position = "absolute";
	this.div.style.width = "40px";
	this.div.style.height = "28px";
	this.div.style.backgroundImage = "url(./img/bird0.png)";
	this.div.style.backgroundRepeat	= "no-repeat";
	this.div.style.left = "50px";
	this.div.style.top = "200px";
	this.div.style.zIndex = "1";
	parentObj.appendChild(this.div);
	},

	fly:function(){
		bird.waingTimer = setInterval(changeImg,120);
		var ups = ["url(./img/up_bird0.png)","url(./img/up_bird1.png)"];
		var downs = ["url(./img/down_bird0.png)","url(./img/down_bird1.png)"];
		var i = 0,j = 0;
		function changeImg(){
			if (bird.fallSpeed < 0) { //向上
				bird.div.style.backgroundImage = ups[i++];
				if (i>1) { i = 0;}
			}
			if(bird.fallSpeed >0){ //向下
				bird.div.style.backgroundImage = downs[j++];
			    if (j >1) {j = 0;}
			}
		}
	},

	fallSpeed:0,
	flyBird:function(){ //控制下落的函数
		bird.flyBirdTimer = setInterval(downAction,40);
		function downAction(){
			bird.div.style.top = bird.div.offsetTop + bird.fallSpeed++ + "px";
			if (bird.div.offsetTop < 0) {
				bird.fallSpeed = 2;
			}
			if (bird.div.offsetTop >= 395) {
				bird.fallSpeed = 0; //这里是触底了  需要停下来
				//clearInterval 用来清理定时器   
				// var timer = setInterval(method,200); 定时器的写法
				//在js中写CS 需要进行相关处理 类似 java 语言拼接字符 来执行修改css 样式的目的   
				//this.div.style.position = "absolute"; 类似这种写法 
				
				clearInterval(bird.waingTimer);
				clearInterval(bird.flyBirdTimer);
			}
			if (bird.fallSpeed > 12) {
				fallSpeed = 12;
			}
		}
	}
}