 function block() {
	 
 	// 构建diV的方法
 	this.createDiv = function(url,height,postionType,left,top){
 		var newDiv = document.createElement("div");
 		newDiv.style.width = "62px";
 		newDiv.style.height = height;
 		newDiv.style.position = postionType;
 		newDiv.style.left = left;
 		newDiv.style.top = top;
 		newDiv.style.backgroundImage = url;
 		return newDiv;
 	};

    this.downHeight = baseObject.rundNum(0,150);

	this.gapHeight = baseObject.rundNum(150,160);
	
    this.upHeight =  312 - this.downHeight - this.gapHeight;

    this.upDivWrap = null;
    this.downDivWrap = null;

 	this.createBlock = function(){
 		//创造 管道
 		var upDiv1 = this.createDiv("url(./img/up_mod.png)",this.upHeight+"px");
 		var upDiv2 = this.createDiv("url(./img/up_pipe.png)","60px");
 		this.upDivWrap = this.createDiv(null,null,"absolute","450px","0px");  //创建一个在最右侧的div

 		this.upDivWrap.appendChild(upDiv1);
		 this.upDivWrap.appendChild(upDiv2);
		 
		 //管帽
		var dowDiv1 = this.createDiv("url(./img/down_pipe.png)","60px");
		//管柱子
		 var dowDiv2 = this.createDiv("url(./img/down_mod.png)",this.downHeight+"px");
		//创造下边管子的DIV
 		this.downDivWrap = this.createDiv(null,null,"absolute","450px",363 - this.downHeight+"px");

 		this.downDivWrap.appendChild(dowDiv1);
		 this.downDivWrap.appendChild(dowDiv2);
		//  直接饮用外部DIV 盒子 添加 因为是 方法函数所以可以使用
 		jsWrapBg.appendChild(this.upDivWrap);
 		jsWrapBg.appendChild(this.downDivWrap);
	 };
	 
 	this.moveBlock = function(){
		 //这里用来移动 管子
		//  这里是用来移动管子DIV 位置的
 		this.upDivWrap.style.left = this.upDivWrap.offsetLeft - 3 + "px";
 		this.downDivWrap.style.left = this.upDivWrap.offsetLeft - 3 + "px";
 	};

};